import os
from telegram import Update, InputFile
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

TOKEN = os.getenv("BOT_TOKEN")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("سلام! فایل هدیه شما آماده‌ست. 🎁")
    with open("10_nokte_salamat_banovan.pdf", "rb") as f:
        await update.message.reply_document(document=InputFile(f, filename="10_nokte_salamat_banovan.pdf"))

if __name__ == '__main__':
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    print("Bot is running...")
    app.run_polling()
