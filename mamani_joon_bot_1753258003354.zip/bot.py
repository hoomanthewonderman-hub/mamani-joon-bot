import logging
from telegram import Update, InputFile
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
import os

TOKEN = "7537307757:AAFJ6zDDZfzhyVqZ_Gcr8pDEohkV4BimLjk"
CHANNEL_USERNAME = "@salamat_banooye_irani"
PDF_PATH = "10_nokte_salamat_banovan.pdf"
INVITE_THRESHOLD = 5

user_invites = {}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id not in user_invites:
        user_invites[user_id] = {"count": 0}
    link = f"https://t.me/{context.bot.username}?start={user_id}"
    await update.message.reply_text(
        f"سلام {update.effective_user.first_name} 🌸\n"
        "این لینک دعوت مخصوص شماست:\n"
        f"{link}\n"
        "۵ نفر رو دعوت کن تا فایل هدیه رو بگیری 🎁"
    )

async def link(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    link = f"https://t.me/{context.bot.username}?start={user_id}"
    await update.message.reply_text(f"🔗 لینک دعوت اختصاصی شما:\n{link}")

async def invite(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    count = user_invites.get(user_id, {}).get("count", 0)
    msg = f"📊 شما تا حالا {count} نفر رو دعوت کردید."
    if count >= INVITE_THRESHOLD:
        msg += "\n🎉 تبریک! فایل هدیه برای شما آماده‌ست."
        with open(PDF_PATH, 'rb') as f:
            await context.bot.send_document(chat_id=update.effective_chat.id, document=InputFile(f))
    await update.message.reply_text(msg)

async def handle_referrals(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if context.args:
        ref_id = int(context.args[0])
        new_user_id = update.effective_user.id
        if new_user_id != ref_id:
            if ref_id not in user_invites:
                user_invites[ref_id] = {"count": 0}
            user_invites[ref_id]["count"] += 1

app = ApplicationBuilder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("start", handle_referrals))
app.add_handler(CommandHandler("link", link))
app.add_handler(CommandHandler("invite", invite))

if __name__ == "__main__":
    import asyncio
    asyncio.run(app.run_polling())
